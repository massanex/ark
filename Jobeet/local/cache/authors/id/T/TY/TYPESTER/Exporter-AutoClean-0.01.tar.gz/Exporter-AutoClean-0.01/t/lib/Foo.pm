package Foo;
use strict;
use warnings;
use Base;

our $data;
$data = method();

1;
