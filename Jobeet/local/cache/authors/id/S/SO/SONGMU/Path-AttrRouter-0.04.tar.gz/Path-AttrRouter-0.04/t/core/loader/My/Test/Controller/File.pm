package My::Test::Controller::File;
use base 'Path::AttrRouter::Controller';

sub index :Path {}

1;

