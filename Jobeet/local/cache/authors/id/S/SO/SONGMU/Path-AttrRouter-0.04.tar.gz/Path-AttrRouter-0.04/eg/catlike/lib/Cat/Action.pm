package Cat::Action;
use Mouse;

extends 'Path::AttrRouter::Action';

__PACKAGE__->meta->make_immutable;

