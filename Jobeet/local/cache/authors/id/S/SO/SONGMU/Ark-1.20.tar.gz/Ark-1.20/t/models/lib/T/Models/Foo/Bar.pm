package T::Models::Foo::Bar;
use Mouse;

sub buzz {
    'buzz!';
}

1;

