package TestApp;
use Ark;

__PACKAGE__->meta->make_immutable;
