package T2::API::Hello;
use Mouse;

sub hello {
    'api hello!';
}

1;

