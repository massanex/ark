[![Build Status](https://travis-ci.org/ark-framework/ark.png?branch=master)](https://travis-ci.org/ark-framework/ark) [![Coverage Status](https://coveralls.io/repos/ark-framework/ark/badge.png?branch=master)](https://coveralls.io/r/ark-framework/ark?branch=master)
# NAME

Ark - light weight Catalyst-ish web application framework

# SYNOPSIS

    use Ark;

# DESCRIPTION

Ark is light weight Catalyst-ish web application framework.

# LICENSE

Copyright (C) Daisuke Murase.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

Daisuke Murase <typester@cpan.org>
