package T2::Models;
use Ark::Models -base;

register_namespaces 'API' => 'T2::API';

1;

